collect_ignore = ['setup.py']
